﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Truck_Analytics
{
    public partial class Sub_Flab : Form
    {
        public Sub_Flab()
        {
            InitializeComponent();
        }

        // Log
        string Msg = "";
        string Log_OldValue = "-";
        string Log_NewValue = "-";


        private void Sub_Flab_Load(object sender, EventArgs e)
        {
            Load_Product();
            Load_Lab_Setting();
            Load_FileConfig();

        }

        private void Load_FileConfig()
        {
            //  StreamReader sw = new StreamReader(Application.StartupPath + "\\config.dll");
            string filename = Application.StartupPath + "\\config.dll";


            if (System.IO.File.Exists(filename))
            {
                System.IO.StreamReader StrRer = new System.IO.StreamReader(filename);

                List<string> listStr = new List<string>();

                while (!StrRer.EndOfStream)
                {
                    listStr.Add(StrRer.ReadLine());
                }

                txt_LabsourceCSV.Text = listStr[0].ToString();
                txt_LabdiscCSV.Text = listStr[1].ToString();
                //txt_scalefileDll.Text = listStr[3].ToString();

                StrRer.Close();
            }


        }

        private void Load_Product()
        {
            SqlConnection con = new SqlConnection(Program.pathdb_Weight);
            con.ConnectionString = Program.pathdb_Weight;
            SqlDataAdapter dtAdapter = new SqlDataAdapter();

            try
            {
                //Product 
                SqlCommand cmd = new SqlCommand("Select [ProductID],[ProductID] +':'+ [ProductName] AS 'ProductName' From  [dbo].[TB_Products]  Where [StatusActive] =1", con);

                DataSet ds4 = new DataSet();
                //ds.Clear();
                SqlDataAdapter da4 = new SqlDataAdapter();
                da4.SelectCommand = cmd;
                da4.Fill(ds4);
                //Load product tab Lab Setup
                cb_product_Lab.DataSource = ds4.Tables[0];
                cb_product_Lab.DisplayMember = "ProductName";
                cb_product_Lab.ValueMember = "ProductID";  
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }

        }


        private void Load_Lab_Setting()
        {
            try
            {
                txt_LabsourceFileVisual.Clear();
                txt_LabdiscFileVisual.Clear();
                txt_LabsourceCSV.Clear();
                txt_LabdiscCSV.Clear();
                txt_LabnameStarch.Clear();
                txt_LabvalueStarch.Clear();
                txt_LabnameVA.Clear();
                txt_LabvalueVA.Clear();
                txt_Density.Clear();
                txt_acceptLoss.Clear();
                txt_qtyproduct.Clear();

                chk_density.Checked = false;
                chk_importAuto.Checked = false;

                SqlConnection con = new SqlConnection(Program.pathdb_Weight);
                con.ConnectionString = Program.pathdb_Weight;
                SqlDataAdapter dtAdapter = new SqlDataAdapter();
                //dtg_vendorStarch.DataSource = null;
                con.Open();

                string sql1 = "SELECT * FROM  [dbo].[TB_LabSetting] WHERE [LabProductID]= '" + cb_product_Lab.SelectedValue.ToString() + "' ";

                SqlCommand CM1 = new SqlCommand(sql1, con);
                SqlDataReader DR1 = CM1.ExecuteReader();

                DR1.Read();
                {
                    txt_LabsourceFileVisual.Text = DR1["LabSourcepathVisual"].ToString();
                    txt_LabdiscFileVisual.Text = DR1["LabDispathVisual"].ToString();
                    txt_LabsourceCSV.Text = DR1["LabSourcepathCSV"].ToString();
                    txt_LabdiscCSV.Text = DR1["LabDispathCSV"].ToString();
                    txt_LabnameStarch.Text = DR1["ColNameStarchNo"].ToString();
                    txt_LabvalueStarch.Text = DR1["ColValueStarchNo"].ToString();
                    txt_LabnameVA.Text = DR1["ColNameVANo"].ToString();
                    txt_LabvalueVA.Text = DR1["ColValueVANo"].ToString();
                    txt_Density.Text = DR1["ValueDensity"].ToString();
                    txt_acceptLoss.Text = DR1["ValidDensity"].ToString();
                    txt_qtyproduct.Text = DR1["Qtyethanal"].ToString();

                    if (DR1["LabCalAvgOrMax"].ToString() == "True")
                    {
                        rdo_Labavg.Checked = true;
                    }
                    else { rdo_Labmaxmin.Checked = false; }

                    if (DR1["ActiveDensity"].ToString() == "True")
                    {
                        chk_density.Checked = true;
                    }
                    else { chk_density.Checked = false; }

                    if (DR1["LabSourchStarch"].ToString() == "True")
                    {
                        chk_sourevisualStarch.Checked = true;
                    }
                    else { chk_sourevisualStarch.Checked = false; }


                    if (DR1["LabMoveAuto"].ToString() == "True")
                    {
                        chk_importAuto.Checked = true;
                    }
                    else { chk_importAuto.Checked = false; }


                    if (DR1["ShowInsertDen"].ToString() == "True")
                    {
                        chk_insertDen.Checked = true;
                    }
                    else { chk_insertDen.Checked = false; }
                }
                DR1.Close();
                con.Close();
            }
            catch { }
        }

        private void cb_product_Lab_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Load_Lab_Setting();
            }
            catch { }
        }

        private void chk_density_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_density.Checked == true)
            {
                txt_Density.Enabled = true; txt_acceptLoss.Enabled = true; txt_qtyproduct.Enabled = true;
            }
            else { txt_Density.Enabled = false; txt_acceptLoss.Enabled = false; txt_qtyproduct.Enabled = false; }
        }

        private void btn_LabsourceFileVisual_Click(object sender, EventArgs e)
        {
            string dummyFileName = "ไฟล์จากต้นปลายทาง!!";

            SaveFileDialog sf = new SaveFileDialog();
            // Feed the dummy name to the save dialog
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
                // Now here's our save folder
                string savePath = Path.GetDirectoryName(sf.FileName);
                txt_LabsourceFileVisual.Text = savePath;
                // Do whatever
            }
        }

        private void btn_LabdiscFileVisual_Click(object sender, EventArgs e)
        {
            string dummyFileName = "ไฟล์ย้ายปลายทาง!!";

            SaveFileDialog sf = new SaveFileDialog();
            // Feed the dummy name to the save dialog
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
                // Now here's our save folder
                string savePath = Path.GetDirectoryName(sf.FileName);
                txt_LabdiscFileVisual.Text = savePath;
                // Do whatever
            }
        }

        private void btn_LabsourcCSV_Click(object sender, EventArgs e)
        {
            string dummyFileName = "ไฟล์จากต้นปลายทาง!!";

            SaveFileDialog sf = new SaveFileDialog();
            // Feed the dummy name to the save dialog
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
                // Now here's our save folder
                string savePath = Path.GetDirectoryName(sf.FileName);
                txt_LabsourceCSV.Text = savePath;
                // Do whatever
            }
        }

        private void btn_LabdesCSV_Click(object sender, EventArgs e)
        {
            string dummyFileName = "ไฟล์จากต้นปลายทาง!!";

            SaveFileDialog sf = new SaveFileDialog();
            // Feed the dummy name to the save dialog
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
                // Now here's our save folder
                string savePath = Path.GetDirectoryName(sf.FileName);
                txt_LabdiscCSV.Text = savePath;
                // Do whatever
            }
        }

        private void btn_labsetting_Click(object sender, EventArgs e)
        {
            F_LabSetting fls = new F_LabSetting();
            fls.ShowDialog();
        }

        private void btn_save_labsetting_Click(object sender, EventArgs e)
        {
            Update_LabSetting();
        }

        private void Update_LabSetting()
        {         

            try
            {
                SqlConnection con = new SqlConnection(Program.pathdb_Weight);
                con.ConnectionString = Program.pathdb_Weight;
                SqlDataAdapter dtAdapter = new SqlDataAdapter();

                int LabCalAvgOrMax = 2;
                int Status_Density = 0;
                int LabSourchStarch = 0;
                int LabMoveAuto = 0;
                int SPApprovVisual = 0;
                int InsertDen = 0;

                if (rdo_Labavg.Checked == true)
                { LabCalAvgOrMax = 1; }
                if (rdo_Labmaxmin.Checked == true)
                { LabCalAvgOrMax = 0; }
                if (chk_density.Checked == true)
                { Status_Density = 1; }
                if (chk_sourevisualStarch.Checked == true)
                { LabSourchStarch = 1; }
                if (chk_importAuto.Checked == true)
                { LabMoveAuto = 1; }
                if (chk_SPappvisual.Checked == true)
                { SPApprovVisual = 1; }
                if (chk_insertDen.Checked == true)
                { InsertDen = 1; }


                int Items_Check = 0;

                con.Open();
                string sql6 = "SELECT Count([LabProductID]) AS 'Items_Check'  FROM  [dbo].[TB_LabSetting] WHERE [LabProductID]='" + cb_product_Lab.SelectedValue.ToString() + "'";
                SqlCommand CM6 = new SqlCommand(sql6, con);
                SqlDataReader DR6 = CM6.ExecuteReader();

                DR6.Read();
                {
                    Items_Check = Convert.ToInt16(DR6["Items_Check"].ToString().Trim());
                }
                DR6.Close();
                con.Close();

                if (Items_Check == 0)
                {
                    con.Open();
                    string sql = "Insert Into  [dbo].[TB_LabSetting] ([LabProductID]) Values ('" + cb_product_Lab.SelectedValue.ToString() + "')";
                    SqlCommand CM = new SqlCommand(sql, con);
                    SqlDataReader DR = CM.ExecuteReader();
                    con.Close();

                    Msg = "TB_LabSetting";
                    Log_NewValue = "LabProductID = " + cb_product_Lab.SelectedValue.ToString();
                    Log_OldValue = "-";


                }
                string sql1 = "";

                con.Open();

                if (chk_density.Checked == true)
                {

                    sql1 = "Update  [dbo].[TB_LabSetting] Set [LabCalAvgOrMax]=" + LabCalAvgOrMax + ",[LabSourcepathVisual]='" + txt_LabsourceFileVisual.Text.Trim() + "',[LabDispathVisual]='" + txt_LabdiscFileVisual.Text.Trim() + "',[LabSourcepathCSV]='" + txt_LabsourceCSV.Text.Trim() + "',[LabDispathCSV]='" + txt_LabdiscCSV.Text.Trim() + "',[ColNameStarchNo]='" + txt_LabnameStarch.Text.Trim() + "',[ColValueStarchNo]=" + txt_LabvalueStarch.Text.Trim() + ",[ColNameVANo]='" + txt_LabnameVA.Text.Trim() + "',[ColValueVANo]=" + txt_LabvalueVA.Text.Trim() + ",[ActiveDensity] = " + Status_Density + ",[ShowInsertDen] = "+ InsertDen + ",[ValueDensity]=" + txt_Density.Text.Trim() + ",[ValidDensity]=" + txt_acceptLoss.Text + ",[Qtyethanal]=" + txt_qtyproduct.Text + ",[LabSourchStarch] = " + LabSourchStarch + ",[LabMoveAuto] = " + LabMoveAuto + "  WHERE [LabProductID]='" + cb_product_Lab.SelectedValue.ToString() + "'";

                    Msg = "Update to Record in Lab Setting (Option Density)!";

                    Log_OldValue = "LabCalAvgOrMax = " + LabCalAvgOrMax.ToString() +
                        "," + "LabSourcepathVisual = " + txt_LabsourceFileVisual.Text.Trim() +
                        "," + "LabDispathVisual = " + txt_LabdiscFileVisual.Text.Trim() +
                        "," + "LabSourcepathCSV = " + txt_LabsourceCSV.Text.Trim() +
                        "," + "LabDispathCSV = " + txt_LabdiscCSV.Text.Trim() +
                        "," + "ColNameStarchNo = " + txt_LabnameStarch.Text.Trim() +
                        "," + "ColValueStarchNo = " + txt_LabvalueStarch.Text.Trim() +
                        "," + "ColNameVANo = " + txt_LabnameVA.Text.Trim() +
                        "," + "ColValueVANo = " + txt_LabvalueVA.Text.Trim() +
                        "," + "ActiveDensity = " + Status_Density.ToString() +
                        "," + "ValueDensity = " + txt_Density.Text.Trim() +
                        "," + "ValidDensity = " + txt_acceptLoss.Text.Trim() +
                        "," + "Qtyethanal =" + txt_qtyproduct.Text.Trim() +
                        "," + "LabSourchStarch = " + LabSourchStarch.ToString() +
                        "," + "LabMoveAuto = " + LabMoveAuto.ToString() +
                        "," + "WHERE LabProductID = " + cb_product_Lab.SelectedValue.ToString();

                    Log_NewValue = "-";

                }
                else
                {
                    sql1 = "Update  [dbo].[TB_LabSetting] Set [LabCalAvgOrMax]=" + LabCalAvgOrMax + ",[LabSourcepathVisual]='" + txt_LabsourceFileVisual.Text.Trim() + "',[LabDispathVisual]='" + txt_LabdiscFileVisual.Text.Trim() + "',[LabSourcepathCSV]='" + txt_LabsourceCSV.Text.Trim() + "',[LabDispathCSV]='" + txt_LabdiscCSV.Text.Trim() + "',[ColNameStarchNo]='" + txt_LabnameStarch.Text.Trim() + "',[ColValueStarchNo]=" + txt_LabvalueStarch.Text.Trim() + ",[ColNameVANo]='" + txt_LabnameVA.Text.Trim() + "',[ColValueVANo]=" + txt_LabvalueVA.Text.Trim() + ",[ActiveDensity] = " + Status_Density + ",[ShowInsertDen] = " + InsertDen + ",[LabSourchStarch] = " + LabSourchStarch + ",[LabMoveAuto] = " + LabMoveAuto + ",[SPApprovVisual]=" + SPApprovVisual + "  WHERE [LabProductID]='" + cb_product_Lab.SelectedValue.ToString() + "'";

                    Msg = "Update to Record in Lab Setting!";
                    Log_OldValue = "LabCalAvgOrMax = " + LabCalAvgOrMax.ToString() +
                            "," + "LabSourcepathVisual = " + txt_LabsourceFileVisual.Text.Trim() +
                            "," + "LabDispathVisual = " + txt_LabdiscFileVisual.Text.Trim() +
                            "," + "LabSourcepathCSV = " + txt_LabsourceCSV.Text.Trim() +
                            "," + "LabDispathCSV = " + txt_LabdiscCSV.Text.Trim() +
                            "," + "ColNameStarchNo = " + txt_LabnameStarch.Text.Trim() +
                            "," + "ColValueStarchNo = " + txt_LabvalueStarch.Text.Trim() +
                            "," + "ColNameVANo = " + txt_LabnameVA.Text.Trim() +
                            "," + "ColValueVANo = " + txt_LabvalueVA.Text.Trim() +
                            "," + "ActiveDensity = " + Status_Density.ToString() +
                            "," + "SPApprovVisual = " + SPApprovVisual.ToString() +
                            "," + "LabSourchStarch = " + LabSourchStarch.ToString() +
                            "," + "LabMoveAuto = " + LabMoveAuto.ToString() +
                            "," + "WHERE LabProductID = " + cb_product_Lab.SelectedValue.ToString();
                    Log_NewValue = "-";

                }

                SqlCommand CM1 = new SqlCommand(sql1, con);
                SqlDataReader DR1 = CM1.ExecuteReader();
                con.Close();

                MessageBox.Show("บันทึกสำเร็จ", "รายงานการบันทึก", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Class_Log CL = new Class_Log();
                CL.tbname = Msg;
                CL.oldvalue = Log_OldValue;
                CL.newvalue = Log_NewValue;
                CL.Save_log();
            }
            catch { }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                txt_LabsourceFileVisual.Text = @"..\pic_temp\";
            }

            else
            {
                string dummyFileName = "ไฟล์จากต้นปลายทาง!!";

                SaveFileDialog sf = new SaveFileDialog();
                // Feed the dummy name to the save dialog
                sf.FileName = dummyFileName;

                if (sf.ShowDialog() == DialogResult.OK)
                {
                    // Now here's our save folder
                    string savePath = Path.GetDirectoryName(sf.FileName);
                    txt_LabsourceFileVisual.Text = savePath;
                    // Do whatever
                }
            }
        }
    }
}
