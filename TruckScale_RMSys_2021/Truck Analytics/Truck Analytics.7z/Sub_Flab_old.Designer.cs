﻿namespace Truck_Analytics
{
    partial class Sub_Flab_old

    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sub_Flab));
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.chk_insertDen = new System.Windows.Forms.CheckBox();
            this.txt_qtyproduct = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txt_acceptLoss = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.chk_density = new System.Windows.Forms.CheckBox();
            this.txt_Density = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.cb_product_Lab = new System.Windows.Forms.ComboBox();
            this.txt_ValidDensity = new System.Windows.Forms.Panel();
            this.btn_save_labsetting = new System.Windows.Forms.Button();
            this.btn_labsetting = new System.Windows.Forms.Button();
            this.rdo_Labavg = new System.Windows.Forms.RadioButton();
            this.rdo_Labmaxmin = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.chk_SPappvisual = new System.Windows.Forms.CheckBox();
            this.label105 = new System.Windows.Forms.Label();
            this.chk_sourevisualStarch = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.btn_LabdiscFileVisual = new System.Windows.Forms.Button();
            this.txt_LabdiscFileVisual = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.btn_LabsourceFileVisual = new System.Windows.Forms.Button();
            this.txt_LabsourceFileVisual = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label107 = new System.Windows.Forms.Label();
            this.chk_importAuto = new System.Windows.Forms.CheckBox();
            this.txt_LabvalueVA = new System.Windows.Forms.TextBox();
            this.txt_LabnameVA = new System.Windows.Forms.TextBox();
            this.txt_LabvalueStarch = new System.Windows.Forms.TextBox();
            this.txt_LabnameStarch = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_LabdiscCSV = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_LabsourceCSV = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btn_LabdesCSV = new System.Windows.Forms.Button();
            this.btn_LabsourcCSV = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox6.SuspendLayout();
            this.txt_ValidDensity.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.chk_insertDen);
            this.groupBox6.Controls.Add(this.txt_qtyproduct);
            this.groupBox6.Controls.Add(this.label82);
            this.groupBox6.Controls.Add(this.txt_acceptLoss);
            this.groupBox6.Controls.Add(this.label72);
            this.groupBox6.Controls.Add(this.chk_density);
            this.groupBox6.Controls.Add(this.txt_Density);
            this.groupBox6.Controls.Add(this.label46);
            this.groupBox6.Controls.Add(this.cb_product_Lab);
            this.groupBox6.Controls.Add(this.txt_ValidDensity);
            this.groupBox6.Controls.Add(this.rdo_Labavg);
            this.groupBox6.Controls.Add(this.rdo_Labmaxmin);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox6.Location = new System.Drawing.Point(0, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1275, 126);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "การคำนวน-งานชั่ง";
            // 
            // chk_insertDen
            // 
            this.chk_insertDen.AutoSize = true;
            this.chk_insertDen.Location = new System.Drawing.Point(430, 59);
            this.chk_insertDen.Name = "chk_insertDen";
            this.chk_insertDen.Size = new System.Drawing.Size(203, 24);
            this.chk_insertDen.TabIndex = 73;
            this.chk_insertDen.Text = "แสดงหน้าคำนวณค่า Density";
            this.chk_insertDen.UseVisualStyleBackColor = true;
            // 
            // txt_qtyproduct
            // 
            this.txt_qtyproduct.Enabled = false;
            this.txt_qtyproduct.Location = new System.Drawing.Point(835, 91);
            this.txt_qtyproduct.Name = "txt_qtyproduct";
            this.txt_qtyproduct.Size = new System.Drawing.Size(106, 26);
            this.txt_qtyproduct.TabIndex = 72;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(736, 94);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(93, 20);
            this.label82.TabIndex = 71;
            this.label82.Text = "ปริมาตรบรรจุ:";
            // 
            // txt_acceptLoss
            // 
            this.txt_acceptLoss.Enabled = false;
            this.txt_acceptLoss.Location = new System.Drawing.Point(835, 58);
            this.txt_acceptLoss.Name = "txt_acceptLoss";
            this.txt_acceptLoss.Size = new System.Drawing.Size(106, 26);
            this.txt_acceptLoss.TabIndex = 70;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(736, 61);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(93, 20);
            this.label72.TabIndex = 69;
            this.label72.Text = "% ยอมรับได้ :";
            // 
            // chk_density
            // 
            this.chk_density.AutoSize = true;
            this.chk_density.Location = new System.Drawing.Point(430, 92);
            this.chk_density.Name = "chk_density";
            this.chk_density.Size = new System.Drawing.Size(149, 24);
            this.chk_density.TabIndex = 49;
            this.chk_density.Text = "คำนวณค่า Density:";
            this.chk_density.UseVisualStyleBackColor = true;
            this.chk_density.CheckedChanged += new System.EventHandler(this.chk_density_CheckedChanged);
            // 
            // txt_Density
            // 
            this.txt_Density.Enabled = false;
            this.txt_Density.Location = new System.Drawing.Point(585, 91);
            this.txt_Density.Name = "txt_Density";
            this.txt_Density.Size = new System.Drawing.Size(106, 26);
            this.txt_Density.TabIndex = 68;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(8, 28);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(46, 20);
            this.label46.TabIndex = 37;
            this.label46.Text = "สินค้า:";
            // 
            // cb_product_Lab
            // 
            this.cb_product_Lab.FormattingEnabled = true;
            this.cb_product_Lab.Location = new System.Drawing.Point(61, 24);
            this.cb_product_Lab.Name = "cb_product_Lab";
            this.cb_product_Lab.Size = new System.Drawing.Size(307, 28);
            this.cb_product_Lab.TabIndex = 36;
            this.cb_product_Lab.SelectedIndexChanged += new System.EventHandler(this.cb_product_Lab_SelectedIndexChanged);
            // 
            // txt_ValidDensity
            // 
            this.txt_ValidDensity.Controls.Add(this.btn_save_labsetting);
            this.txt_ValidDensity.Controls.Add(this.btn_labsetting);
            this.txt_ValidDensity.Dock = System.Windows.Forms.DockStyle.Right;
            this.txt_ValidDensity.Location = new System.Drawing.Point(1072, 22);
            this.txt_ValidDensity.Name = "txt_ValidDensity";
            this.txt_ValidDensity.Size = new System.Drawing.Size(200, 101);
            this.txt_ValidDensity.TabIndex = 26;
            // 
            // btn_save_labsetting
            // 
            this.btn_save_labsetting.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_save_labsetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_save_labsetting.Image = ((System.Drawing.Image)(resources.GetObject("btn_save_labsetting.Image")));
            this.btn_save_labsetting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_save_labsetting.Location = new System.Drawing.Point(111, 30);
            this.btn_save_labsetting.Margin = new System.Windows.Forms.Padding(5);
            this.btn_save_labsetting.Name = "btn_save_labsetting";
            this.btn_save_labsetting.Size = new System.Drawing.Size(89, 71);
            this.btn_save_labsetting.TabIndex = 23;
            this.btn_save_labsetting.Text = "Save";
            this.btn_save_labsetting.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_save_labsetting.UseVisualStyleBackColor = true;
            this.btn_save_labsetting.Click += new System.EventHandler(this.btn_save_labsetting_Click);
            // 
            // btn_labsetting
            // 
            this.btn_labsetting.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_labsetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_labsetting.ForeColor = System.Drawing.Color.Blue;
            this.btn_labsetting.Location = new System.Drawing.Point(0, 0);
            this.btn_labsetting.Name = "btn_labsetting";
            this.btn_labsetting.Size = new System.Drawing.Size(200, 30);
            this.btn_labsetting.TabIndex = 25;
            this.btn_labsetting.Text = "การตั้งค่าการวิเคราะห์";
            this.btn_labsetting.UseVisualStyleBackColor = true;
            this.btn_labsetting.Click += new System.EventHandler(this.btn_labsetting_Click);
            // 
            // rdo_Labavg
            // 
            this.rdo_Labavg.AutoSize = true;
            this.rdo_Labavg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.rdo_Labavg.Location = new System.Drawing.Point(12, 59);
            this.rdo_Labavg.Name = "rdo_Labavg";
            this.rdo_Labavg.Size = new System.Drawing.Size(349, 24);
            this.rdo_Labavg.TabIndex = 12;
            this.rdo_Labavg.Text = "แบบค่าเฉลี่ย - ส่วนแม่มีค่า = 45%  ส่วนลูกมีค่า=55%";
            this.rdo_Labavg.UseVisualStyleBackColor = true;
            // 
            // rdo_Labmaxmin
            // 
            this.rdo_Labmaxmin.AutoSize = true;
            this.rdo_Labmaxmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.rdo_Labmaxmin.Location = new System.Drawing.Point(12, 92);
            this.rdo_Labmaxmin.Name = "rdo_Labmaxmin";
            this.rdo_Labmaxmin.Size = new System.Drawing.Size(388, 24);
            this.rdo_Labmaxmin.TabIndex = 11;
            this.rdo_Labmaxmin.Text = "แบบค่าสูงสุด - เลือกค่าใดค่าหนึ่งมีเป็นค่าสูงสุดของผลตัวอย่าง";
            this.rdo_Labmaxmin.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.chk_SPappvisual);
            this.groupBox10.Controls.Add(this.label105);
            this.groupBox10.Controls.Add(this.chk_sourevisualStarch);
            this.groupBox10.Controls.Add(this.checkBox4);
            this.groupBox10.Controls.Add(this.btn_LabdiscFileVisual);
            this.groupBox10.Controls.Add(this.txt_LabdiscFileVisual);
            this.groupBox10.Controls.Add(this.label41);
            this.groupBox10.Controls.Add(this.btn_LabsourceFileVisual);
            this.groupBox10.Controls.Add(this.txt_LabsourceFileVisual);
            this.groupBox10.Controls.Add(this.label42);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox10.Location = new System.Drawing.Point(0, 146);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1275, 116);
            this.groupBox10.TabIndex = 6;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "การตั้งค่างานแบบกายภาพ (Visual)";
            // 
            // chk_SPappvisual
            // 
            this.chk_SPappvisual.AutoSize = true;
            this.chk_SPappvisual.Location = new System.Drawing.Point(897, 28);
            this.chk_SPappvisual.Name = "chk_SPappvisual";
            this.chk_SPappvisual.Size = new System.Drawing.Size(198, 24);
            this.chk_SPappvisual.TabIndex = 75;
            this.chk_SPappvisual.Text = "SP อนุมัติกรณีไม่ผ่านเกณฑ์";
            this.chk_SPappvisual.UseVisualStyleBackColor = true;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(674, 71);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(69, 20);
            this.label105.TabIndex = 74;
            this.label105.Text = "คำอธิบาย:";
            // 
            // chk_sourevisualStarch
            // 
            this.chk_sourevisualStarch.AutoSize = true;
            this.chk_sourevisualStarch.Checked = true;
            this.chk_sourevisualStarch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_sourevisualStarch.Location = new System.Drawing.Point(705, 28);
            this.chk_sourevisualStarch.Name = "chk_sourevisualStarch";
            this.chk_sourevisualStarch.Size = new System.Drawing.Size(169, 24);
            this.chk_sourevisualStarch.TabIndex = 73;
            this.chk_sourevisualStarch.Text = "ใช้เกณฑ์จากตารางแป้ง";
            this.chk_sourevisualStarch.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Location = new System.Drawing.Point(596, 28);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(85, 24);
            this.checkBox4.TabIndex = 48;
            this.checkBox4.Text = "ค่าเริ่มต้น";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // btn_LabdiscFileVisual
            // 
            this.btn_LabdiscFileVisual.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LabdiscFileVisual.BackgroundImage")));
            this.btn_LabdiscFileVisual.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_LabdiscFileVisual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_LabdiscFileVisual.Location = new System.Drawing.Point(168, 65);
            this.btn_LabdiscFileVisual.Name = "btn_LabdiscFileVisual";
            this.btn_LabdiscFileVisual.Size = new System.Drawing.Size(40, 26);
            this.btn_LabdiscFileVisual.TabIndex = 47;
            this.btn_LabdiscFileVisual.UseVisualStyleBackColor = true;
            this.btn_LabdiscFileVisual.Click += new System.EventHandler(this.btn_LabdiscFileVisual_Click);
            // 
            // txt_LabdiscFileVisual
            // 
            this.txt_LabdiscFileVisual.Location = new System.Drawing.Point(214, 65);
            this.txt_LabdiscFileVisual.Name = "txt_LabdiscFileVisual";
            this.txt_LabdiscFileVisual.Size = new System.Drawing.Size(369, 26);
            this.txt_LabdiscFileVisual.TabIndex = 45;
            this.txt_LabdiscFileVisual.Text = "...";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(17, 65);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(147, 20);
            this.label41.TabIndex = 46;
            this.label41.Text = "แหล่งไฟล์รูป ปลายทาง:";
            // 
            // btn_LabsourceFileVisual
            // 
            this.btn_LabsourceFileVisual.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LabsourceFileVisual.BackgroundImage")));
            this.btn_LabsourceFileVisual.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_LabsourceFileVisual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_LabsourceFileVisual.Location = new System.Drawing.Point(168, 27);
            this.btn_LabsourceFileVisual.Name = "btn_LabsourceFileVisual";
            this.btn_LabsourceFileVisual.Size = new System.Drawing.Size(40, 26);
            this.btn_LabsourceFileVisual.TabIndex = 44;
            this.btn_LabsourceFileVisual.UseVisualStyleBackColor = true;
            this.btn_LabsourceFileVisual.Click += new System.EventHandler(this.btn_LabsourceFileVisual_Click);
            // 
            // txt_LabsourceFileVisual
            // 
            this.txt_LabsourceFileVisual.Location = new System.Drawing.Point(214, 27);
            this.txt_LabsourceFileVisual.Name = "txt_LabsourceFileVisual";
            this.txt_LabsourceFileVisual.Size = new System.Drawing.Size(369, 26);
            this.txt_LabsourceFileVisual.TabIndex = 42;
            this.txt_LabsourceFileVisual.Text = "...";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(17, 30);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(133, 20);
            this.label42.TabIndex = 43;
            this.label42.Text = "แหล่งไฟล์รูป ต้นทาง:";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label107);
            this.groupBox14.Controls.Add(this.chk_importAuto);
            this.groupBox14.Controls.Add(this.txt_LabvalueVA);
            this.groupBox14.Controls.Add(this.txt_LabnameVA);
            this.groupBox14.Controls.Add(this.txt_LabvalueStarch);
            this.groupBox14.Controls.Add(this.txt_LabnameStarch);
            this.groupBox14.Controls.Add(this.label30);
            this.groupBox14.Controls.Add(this.label31);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Controls.Add(this.label28);
            this.groupBox14.Controls.Add(this.txt_LabdiscCSV);
            this.groupBox14.Controls.Add(this.label27);
            this.groupBox14.Controls.Add(this.txt_LabsourceCSV);
            this.groupBox14.Controls.Add(this.label26);
            this.groupBox14.Controls.Add(this.btn_LabdesCSV);
            this.groupBox14.Controls.Add(this.btn_LabsourcCSV);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox14.Location = new System.Drawing.Point(0, 262);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1275, 153);
            this.groupBox14.TabIndex = 50;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "การตั้งค่าแบบนำไฟล์เข้า (Import File)  From File .DLL";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(247, 37);
            this.label107.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(1072, 20);
            this.label107.TabIndex = 75;
            this.label107.Text = "คำอธิบาย: หากเปิดใช้งานนี้ ที่หน้าดึงข้อมูลจากเครื่อง NIR จะต้องค้นหาแหล่งไฟล์ CS" +
    "V และจะต้องเลือกค่าในช่อง Cell ที่ต้องการบันทึกเอง และจะไม่มีการย้ายไฟล์ที่เปิดเ" +
    "รียกใช้งาน";
            // 
            // chk_importAuto
            // 
            this.chk_importAuto.AutoSize = true;
            this.chk_importAuto.Location = new System.Drawing.Point(21, 36);
            this.chk_importAuto.Margin = new System.Windows.Forms.Padding(2);
            this.chk_importAuto.Name = "chk_importAuto";
            this.chk_importAuto.Size = new System.Drawing.Size(203, 24);
            this.chk_importAuto.TabIndex = 64;
            this.chk_importAuto.Text = "ดึงข้อมูลและย้ายไฟล์อัตโนมัติ";
            this.chk_importAuto.UseVisualStyleBackColor = true;
            // 
            // txt_LabvalueVA
            // 
            this.txt_LabvalueVA.Location = new System.Drawing.Point(1076, 102);
            this.txt_LabvalueVA.Name = "txt_LabvalueVA";
            this.txt_LabvalueVA.Size = new System.Drawing.Size(76, 26);
            this.txt_LabvalueVA.TabIndex = 63;
            this.txt_LabvalueVA.Text = "0";
            // 
            // txt_LabnameVA
            // 
            this.txt_LabnameVA.Location = new System.Drawing.Point(1076, 71);
            this.txt_LabnameVA.Name = "txt_LabnameVA";
            this.txt_LabnameVA.Size = new System.Drawing.Size(76, 26);
            this.txt_LabnameVA.TabIndex = 62;
            this.txt_LabnameVA.Text = "-";
            // 
            // txt_LabvalueStarch
            // 
            this.txt_LabvalueStarch.Location = new System.Drawing.Point(853, 102);
            this.txt_LabvalueStarch.Name = "txt_LabvalueStarch";
            this.txt_LabvalueStarch.Size = new System.Drawing.Size(76, 26);
            this.txt_LabvalueStarch.TabIndex = 61;
            this.txt_LabvalueStarch.Text = "0";
            // 
            // txt_LabnameStarch
            // 
            this.txt_LabnameStarch.Location = new System.Drawing.Point(853, 71);
            this.txt_LabnameStarch.Name = "txt_LabnameStarch";
            this.txt_LabnameStarch.Size = new System.Drawing.Size(76, 26);
            this.txt_LabnameStarch.TabIndex = 60;
            this.txt_LabnameStarch.Text = "-";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(932, 105);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(140, 20);
            this.label30.TabIndex = 59;
            this.label30.Text = "คอลัมน์ค่าที่เลือก VA:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(932, 73);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(141, 20);
            this.label31.TabIndex = 58;
            this.label31.Text = "คอลัมน์ชื่อที่เลือก VA:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(710, 105);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(139, 20);
            this.label29.TabIndex = 57;
            this.label29.Text = "คอลัมน์ค่าที่เลือกแป้ง:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(710, 73);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(140, 20);
            this.label28.TabIndex = 56;
            this.label28.Text = "คอลัมน์ชื่อที่เลือกแป้ง:";
            // 
            // txt_LabdiscCSV
            // 
            this.txt_LabdiscCSV.Location = new System.Drawing.Point(272, 102);
            this.txt_LabdiscCSV.Name = "txt_LabdiscCSV";
            this.txt_LabdiscCSV.Size = new System.Drawing.Size(433, 26);
            this.txt_LabdiscCSV.TabIndex = 53;
            this.txt_LabdiscCSV.Text = "...";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(17, 105);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(199, 20);
            this.label27.TabIndex = 54;
            this.label27.Text = "แหล่งย้ายไฟล์  .CSV ปลายทาง:";
            // 
            // txt_LabsourceCSV
            // 
            this.txt_LabsourceCSV.Location = new System.Drawing.Point(272, 71);
            this.txt_LabsourceCSV.Name = "txt_LabsourceCSV";
            this.txt_LabsourceCSV.Size = new System.Drawing.Size(433, 26);
            this.txt_LabsourceCSV.TabIndex = 50;
            this.txt_LabsourceCSV.Text = "...";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(17, 73);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(192, 20);
            this.label26.TabIndex = 51;
            this.label26.Text = "แหล่งเรียกไฟล์  .CSV ต้นทาง:";
            // 
            // btn_LabdesCSV
            // 
            this.btn_LabdesCSV.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LabdesCSV.BackgroundImage")));
            this.btn_LabdesCSV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_LabdesCSV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_LabdesCSV.Location = new System.Drawing.Point(226, 102);
            this.btn_LabdesCSV.Name = "btn_LabdesCSV";
            this.btn_LabdesCSV.Size = new System.Drawing.Size(40, 26);
            this.btn_LabdesCSV.TabIndex = 55;
            this.btn_LabdesCSV.UseVisualStyleBackColor = true;
            this.btn_LabdesCSV.Click += new System.EventHandler(this.btn_LabdesCSV_Click);
            // 
            // btn_LabsourcCSV
            // 
            this.btn_LabsourcCSV.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LabsourcCSV.BackgroundImage")));
            this.btn_LabsourcCSV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_LabsourcCSV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btn_LabsourcCSV.Location = new System.Drawing.Point(226, 70);
            this.btn_LabsourcCSV.Name = "btn_LabsourcCSV";
            this.btn_LabsourcCSV.Size = new System.Drawing.Size(40, 26);
            this.btn_LabsourcCSV.TabIndex = 52;
            this.btn_LabsourcCSV.UseVisualStyleBackColor = true;
            this.btn_LabsourcCSV.Click += new System.EventHandler(this.btn_LabsourcCSV_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Plum;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1275, 20);
            this.panel1.TabIndex = 51;
            // 
            // Sub_Flab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1275, 692);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Sub_Flab";
            this.Text = "Sub_Flab";
            this.Load += new System.EventHandler(this.Sub_Flab_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.txt_ValidDensity.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txt_qtyproduct;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txt_acceptLoss;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.CheckBox chk_density;
        private System.Windows.Forms.TextBox txt_Density;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cb_product_Lab;
        private System.Windows.Forms.Panel txt_ValidDensity;
        private System.Windows.Forms.Button btn_save_labsetting;
        private System.Windows.Forms.Button btn_labsetting;
        private System.Windows.Forms.RadioButton rdo_Labavg;
        private System.Windows.Forms.RadioButton rdo_Labmaxmin;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.CheckBox chk_SPappvisual;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.CheckBox chk_sourevisualStarch;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Button btn_LabdiscFileVisual;
        private System.Windows.Forms.TextBox txt_LabdiscFileVisual;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button btn_LabsourceFileVisual;
        private System.Windows.Forms.TextBox txt_LabsourceFileVisual;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.CheckBox chk_importAuto;
        private System.Windows.Forms.TextBox txt_LabvalueVA;
        private System.Windows.Forms.TextBox txt_LabnameVA;
        private System.Windows.Forms.TextBox txt_LabvalueStarch;
        private System.Windows.Forms.TextBox txt_LabnameStarch;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_LabdiscCSV;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_LabsourceCSV;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btn_LabdesCSV;
        private System.Windows.Forms.Button btn_LabsourcCSV;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chk_insertDen;
    }
}